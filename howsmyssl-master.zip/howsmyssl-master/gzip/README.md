This code is from https://PuerkitoBio/ghost by Martin Angers. See
LICENSE for licensing details.

The ghost library includes many dependencies that are not in use in
this codebase (e.g. redis), so we copied the relevant code instead.
